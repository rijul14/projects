import java.util.*;

public class FlightMap {
	public Map<City,Map<City,Integer> > fmap; //key = City, Value = map of neighbors (key) and costs (value)
	public City src; //source city
	public Map<String,City> citMap; //string, city map
	
	public FlightMap() {
		fmap = new HashMap<City,Map<City,Integer> >();
		citMap = new HashMap<String,City>();
	}
	
	public void addPairing(City c, Map<City,Integer> m) {
		this.fmap.put(c, m);
	}
	
	public void setSrc (City c) {
		this.src = c;
	}
	
	public City getSrc () {
		return this.src;
	}
	
	public void addLetterCity(String s, City c) {
		citMap.put(s, c);
	}
	
	public Map<String,City> getLetterCity() {
		return this.citMap;
	}
	
	public Map<City,Map<City,Integer> > getPairings() {
		return this.fmap;
	}
}
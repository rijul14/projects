import static org.junit.Assert.*;

import java.util.HashMap;
import java.util.Map;

import org.junit.Test;

public class TestFlightMap {

	@Test
	public void testGetSrc() {
		FlightMap tester = new FlightMap();
		City p = new City("p",0,null);
		tester.setSrc(p);
		assertTrue(p.getName() == tester.getSrc().getName());
	}
	
	@Test
	public void testGetLetterCity() {
		FlightMap tester = new FlightMap();
		Map<String,City> hmap = new HashMap<String,City>();
		City p = new City("p",0,null);
		City c = new City("c",12,p);
		City g = new City("g",20,c);
		tester.setSrc(c);
		tester.addLetterCity("p", p);
		tester.addLetterCity("c", c);
		tester.addLetterCity("g", g);
		hmap.put("p", p);
		hmap.put("c", c);
		hmap.put("g", g);
		assertTrue(hmap.size() == tester.getLetterCity().size());
	}
}

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
public class City {
	public boolean visited; //used in BFS and input file parsing
	public Map<City,Integer> neighbors; //map of neighbor cities and costs
	public String c; //city name
	public int parentCost;
	public City parent;
	
	public City(String c, int pCost, City parent) {
		this.neighbors = new HashMap<City,Integer>();
		this.c = c;
		this.visited = false;
		this.parentCost = pCost;
		this.parent = parent;
	}
	
	public void addNeighbor (City c, Integer i) {
		this.neighbors.put(c, i);
		this.visited = true;
	}
	
	public void setParent(City p) {
		this.parent = p;
	}
	
	public City getParent() {
		return this.parent;
	}
	
	public Map<City,Integer> getNeighbors () {
		return this.neighbors;
	}
	
	public boolean getVisited() {
		return this.visited;
	}
	
	public void setVisited(boolean p) {
		this.visited = p;
	}
	
	public String getName() {
		return this.c;
	}
	
	public void setPCost (int cost) {
		this.parentCost = cost;
	}
	
	public int getPCost () {
		return this.parentCost;
	}
}
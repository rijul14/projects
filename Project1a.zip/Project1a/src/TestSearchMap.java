import static org.junit.Assert.*;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

import org.junit.Test;



public class TestSearchMap {

	@Test
	public void testReadFile() {
		SearchMap s = new SearchMap();
		FlightMap f = s.readFile("inputfile.txt");
		assertTrue(9 == f.getPairings().size());
	}
	
	@Test
	public void testBfs() throws IOException {
		Path path1 = null;
		Path path2 = null;
		try {
			path1 = Files.createTempFile("outputfile", ".txt");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			path2 = Files.createTempFile("expectedOutputFile", ".txt");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	    try (BufferedReader bf1 = Files.newBufferedReader(path1);
            BufferedReader bf2 = Files.newBufferedReader(path2)) {
           long lineNumber = 1;
           String line1 = "", line2 = "";
           while ((line1 = bf1.readLine()) != null) {
               line2 = bf2.readLine();
               lineNumber++;
               assertTrue(line1 == line2);
           }
       }
	}
}

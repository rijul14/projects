import java.util.*;
import java.io.*;

public class SearchMap {
	static Scanner scan = new Scanner (System.in);
	static FlightMap fl = new FlightMap();
	static String input;
	static String output;
	static FileWriter w;
	static PrintWriter pw;
	static int cost = 0;
	//to find path
	static ArrayList<City> al = new ArrayList<City>(); 
	//String formatting
	static String o1 = ""; 
	static String o2 = "";
	static String o3 = "";
	
	//reads input file and returns a FlightMap with all cities, neighbors, and costs stored
	public static FlightMap readFile(String input) {
		try {
			scan = new Scanner(new FileReader(input));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//source city
		String src = scan.nextLine();
		City source = new City(src,0,null);
		fl.setSrc(source);
		fl.addLetterCity(src, source);
		//continues until end of file
		while (scan.hasNextLine()) {
			String[] l = scan.nextLine().split(" "); //stores source city, dest city, and cost
			//if source city is already in the map
			if (fl.getLetterCity().containsKey(l[0])) {
				//if dest city is not in map
				if (!fl.getLetterCity().containsKey(l[1])) {
					City n = new City(l[1],Integer.valueOf(Integer.parseInt(l[2])),fl.getLetterCity().get(l[0]));
					fl.addLetterCity(l[1], n);
					City p = fl.getLetterCity().get(l[0]);
					p.addNeighbor(n, Integer.valueOf(Integer.parseInt(l[2])));
				}
				//if dest city is in map
				else {
					City start = fl.getLetterCity().get(l[0]);
					City neighb = fl.getLetterCity().get(l[1]);
					start.addNeighbor(neighb, Integer.parseInt(l[2]));
				}
			}
			//if source city is not in map
			else {
				City start = new City (l[0],0,null);
				fl.addLetterCity(l[0], start);
				//if dest city is not in map
				if (!fl.getLetterCity().containsKey(l[1])) {
					City n = new City(l[1],Integer.valueOf(Integer.parseInt(l[2])),start);
					fl.addLetterCity(l[1], n);
					start.addNeighbor(n, Integer.valueOf(Integer.parseInt(l[2])));
				}
				//if dest city is already in map
				else {
					City neighb = fl.getLetterCity().get(l[1]);
					start.addNeighbor(neighb, Integer.parseInt(l[2]));
				}
			}
		}
		//stores the official FlightMap with all source cities and dest cities
		Iterator<Map.Entry<String, City>> itr = fl.getLetterCity().entrySet().iterator();
        while(itr.hasNext())
        {
             Map.Entry<String, City> entry = itr.next();
             City c = entry.getValue();
             fl.addPairing(c, c.getNeighbors());
        }
        scan.close();
		return fl;
	}
	
	public static void bfs (FlightMap flight) {
		try {
			w = new FileWriter(output);
			pw = new PrintWriter(w);
			pw.println("Destination  " + "Flight Route from " + flight.getSrc().getName() + "   Total Cost");
		}
		catch (IOException e) {
			e.printStackTrace();
	    }
		//sets all cities' visited value to false initially
		Iterator<Map.Entry<String, City>> itr = fl.getLetterCity().entrySet().iterator();
        while(itr.hasNext())
        {
             Map.Entry<String, City> entry = itr.next();
             entry.getValue().setVisited(false);
        }
        Queue<City> q = new LinkedList<City>();
        //starting point of queue
        q.add(flight.getSrc());
        flight.getSrc().setVisited(true);
        while (!q.isEmpty()) {
        	City el = q.remove();
        	Map<City,Integer> m = el.getNeighbors();
        	Iterator<Map.Entry<City, Integer>> neigh = m.entrySet().iterator();
        	//goes through all neighbors of every city
            while(neigh.hasNext())
            {
	             Map.Entry<City, Integer> val = neigh.next();
	             City temp = val.getKey();
	             //visit only if city hasn't already been visited
	             if (temp != null && temp.getVisited() == false) {
	            	 q.add(temp);
	            	 temp.setVisited(true);
	            	 //if city's parent is source
	            	 if (temp.getParent().getName() == flight.getSrc().getName()) {
	            		 cost = temp.getPCost();
	            		 al.add(temp);
	            		 al.add(flight.getSrc());
	            	 }
	            	 //backtracks until path to source is found and cost of all edges is found
	            	 else {
	                	 while (temp.getName() != flight.getSrc().getName()) {
	                		 cost += temp.getPCost();
	                		 al.add(temp);
	                		 temp = temp.getParent();
	                	 }
	                	 al.add(flight.getSrc());
	            	 }
	            	 //o1 stores dest city name
					o1 = val.getKey().getName();
					for (int i = al.size() - 1; i >= 0; --i) {
						//o2 stores path to dest city
						if (i != 0) {
							o2 += al.get(i).getName() + ", ";
						}
						else {
							o2 += al.get(i).getName();
						}
					}
					//stores total cost
					o3 = "$" + String.valueOf(cost);
					String fin = String.format("%-16s%-24s%-9s", o1, o2, o3);
		            pw.println(fin);
	             }
	             //resets values to start new calculation for every city
	             cost = 0;
	             o1 = "";
	             o2 = "";
	             o3 = "";
	             al.clear();
            }
        	
        }
        try {
			w.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void main (String[] args) {
		FlightMap flight = new FlightMap();
		//gets input and output files from user
		System.out.print("java SearchMap ");
		input = scan.next();
		output = scan.next();
		flight = readFile(input);
		bfs(flight);
	}
	
}
#include <iostream>
#include <fstream>
#include "stack.h"

using namespace std;

int main(int argc, char* argv[])
{
  if(argc < 3){
    cerr << "Please provide the input and output filenames" << endl;
    return 1;
  }
  // Add your code here
  ifstream ifile(argv[1]);
  if (ifile.fail()){
    ifile.close();
    return 1;
  }
  ofstream ofile(argv[2]);
  if (ofile.fail()){
    ofile.close();
    return 1;
  }
  Stack<int> s;
  int num;
  while (ifile >> num){
    if (num <= 0){
      s.push(num);
    }
    else {
      if (num > (int) (s.size()))
      {
        num = (int) s.size();
      }
      for (int i = 0; i < num; i++){
        if (s.top() == 0){
          ofile << "black" << " ";
        }
        else if (s.top() == -1){
          ofile << "gray" << " ";
        }
        s.pop();
      }
      ofile << endl;
    }
  }
  ifile.close();
  ofile.close();
  return 0;
}

#include <iostream>
#include "heap.h"

using namespace std;

int main ()
{
    Heap<int> h(3);
    h.push(5);
    h.push(3);
    h.push(8);
    h.push(20);
    h.push(1);
    h.push(-3);
    h.push(-20);
    h.push(-40);
    cout << h.top() << endl;
    h.pop();
    cout << h.top() << endl;
    h.pop();
    cout << h.top() << endl;
    h.pop();
    cout << h.top() << endl;
    h.pop();
    cout << h.top() << endl;
    h.pop();
    cout << h.top() << endl;
    h.pop();
    cout << h.top() << endl;
    h.pop();
    cout << h.top() << endl;
    return 0;
}
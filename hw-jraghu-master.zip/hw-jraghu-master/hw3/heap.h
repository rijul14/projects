#ifndef HEAP_H
#define HEAP_H
#include <functional>
#include <stdexcept>
#include <vector>

template <typename T, typename PComparator = std::less<T> >
class Heap
{
 public:
  /// Constructs an m-ary heap for any m >= 2
  Heap(int m, PComparator c = PComparator());

  /// Destructor as needed
  ~Heap();

  /// Adds an item
  void push(const T& item);

  /// returns the element at the top of the heap 
  ///  max (if max-heap) or min (if min-heap)
  T const & top() const;

  /// Removes the top element
  void pop();

  /// returns true if the heap is empty
  bool empty() const;

  void trickleUp(int loc);

  void heapify(int index);

 private:
  /// Add whatever helper functions and data members you need below
  std::vector<T> vec;
  int m_;
  PComparator c_;
};

// Add implementation of member functions here
template <typename T, typename PComparator>
Heap<T,PComparator>::Heap(int m, PComparator c) {
  m_ = m;
  c_ = c;
}

template <typename T, typename PComparator>
Heap<T,PComparator>::~Heap() {
  vec.clear();
}

template <typename T, typename PComparator>
void Heap<T,PComparator>::push(const T& item) {
  vec.push_back(item);
  trickleUp(vec.size() - 1);
}

template <typename T, typename PComparator>
bool Heap<T,PComparator>::empty() const {
  if (vec.size() == 0)
  {
    return true;
  }
  return false;
}
// We will start top() for you to handle the case of 
// calling top on an empty heap
template <typename T, typename PComparator>
T const & Heap<T,PComparator>::top() const
{
  // Here we use exceptions to handle the case of trying
  // to access the top element of an empty heap
  if(empty()){
    throw std::logic_error("can't top an empty heap");
  }
  // If we get here we know the heap has at least 1 item
  // Add code to return the top element
  return vec[0];
}


// We will start pop() for you to handle the case of 
// calling top on an empty heap
template <typename T, typename PComparator>
void Heap<T,PComparator>::pop()
{
  if(empty()){
    throw std::logic_error("can't pop an empty heap");
  }
  vec[0] = vec.back();
  vec.pop_back();
  heapify(0);
}

template <typename T, typename PComparator>
void Heap<T,PComparator>::trickleUp(int loc) {
  int parent;
  if (loc % m_ == 0)
  {
    parent = (loc/m_) - 1;
  }
  else 
  {
    parent = loc/m_;
  }
  while (parent >= 0 && c_(vec[loc],vec[parent]))
  {
    T temp = vec[loc];
    vec[loc] = vec[parent];
    vec[parent] = temp;
    loc = parent;
    if (parent % m_ == 0)
    {
      parent = (loc/m_) - 1;
    }
    else 
    {
      parent = loc/m_;
    }
  }
}

template <typename T, typename PComparator>
void Heap<T,PComparator>::heapify(int index) {
  if (((m_ * index) + 1) >= (int)(vec.size()))
  {
    return;
  }
  int child = (index*m_) + 1;
  for (int i = 1; i <= m_; i++)
  {
    if (child < (int)(vec.size()) && ((index*m_) + i) < (int)(vec.size()))
    {
      if (c_(vec[(index*m_) + i],vec[child]))
      {
        child = (index*m_) + i;
      }
    }
  }
  if (c_(vec[child],vec[index]))
  {
    T temp = vec[index];
    vec[index] = vec[child];
    vec[child] = temp;
    heapify(child);
  }
}

#endif


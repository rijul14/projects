#include <iostream>
#include <fstream>
#include <stdexcept>
#include <iomanip>
#include <algorithm>
#include "huffman.h"
using namespace std;

// Complete
RawTextVector AsciiHexIO::read(const char* filename)
{
    RawTextVector text;
    ifstream ifile(filename);
    if(ifile.fail()){
        throw std::invalid_argument("Bad input filename");
    }
    while(!ifile.fail()) {
        char c;
        string word;
        for(int i=0; i < 4; i++){
            ifile >> c;
            if(ifile.fail()){
                if(i > 0) {
                    throw std::runtime_error(
                        "Bad file format...did not find multiple of 4 hex characters");
                }
                else {
                    break; // normal exit
                }
            }
            else {
                word += c;
            }
        }
        if(word.size() == 4) {
            text.push_back(word);
        }
    }
    ifile.close();
    return text;
}

// Complete
void AsciiHexIO::write(const char* filename, const RawTextVector&  text)
{
    const size_t NUM_WORDS_PER_LINE = 8;
    ofstream ofile(filename);
    if(ofile.fail()){
        throw std::runtime_error("Unable to open output file");
    }
    size_t i = 0;
    for( const auto & word : text ){
        ofile << word;
        if(i % NUM_WORDS_PER_LINE != NUM_WORDS_PER_LINE-1 ){
            ofile << " ";
        }
        else {
            ofile << endl;
        }
        i++;
    }
    ofile.close();
}

// Complete
void AsciiHuffmanIo::writeCodedText(
    const char* filename, 
    const CompressedData& inText, 
    const CodeKeyMap& code)
{
    ofstream ofile(filename);
    ofile << code.size() << endl;
    // copy from map to vector so we can sort
    typedef pair<string,string> StrStrPair;
    vector< StrStrPair > codesToSort(code.begin(), code.end());
    std::sort(
        codesToSort.begin(), codesToSort.end(), 
        [] (const StrStrPair& s1, const StrStrPair& s2) -> bool
            { return (s1.first.size() < s2.first.size()) ||
                     (s1.first.size() == s2.first.size() && s1.first < s2.first); } );
    for(const auto& pair : codesToSort) {
        ofile << pair.first << " " << pair.second << endl;
    }
    ofile << inText << endl;
    ofile.close();
}

// To be completed
void AsciiHuffmanIo::readCodedText(
    const char* filename, 
    CompressedData& outText, 
    CodeKeyMap& code)
{
    // clear old contents of the output parameters that this function
    // should fill in
    code.clear();
    outText.clear();

    // Complete the code below
    ifstream ifile(filename);
    if(ifile.fail()){
        throw runtime_error("Cannot open file");
    }
    size_t size;
    ifile >> size;
    for (int i = 0; i < (int)(size); i++)
    {
        string huffcode;
        string huffkey;
        ifile >> huffcode >> huffkey;
        code.insert(make_pair(huffcode,huffkey));
    }
    ifile >> outText;
}

// To be completed
void HuffmanCoder::compress(
    const RawTextVector& inText, 
    CompressedData& outText, 
    CodeKeyMap& codes)
{
    // Clear old contents of the output parameters that this function should fill in
    codes.clear();
    outText.clear();

    // Add your code here
    KeyFrequencyMap count;
    KeyCodeMap keycode;
    Heap<HeapItem> h(2);
    outText = "";
    for (unsigned int i = 0; i < inText.size(); i++)
    {
        if (count.find(inText[i]) != count.end())
        {
            map<string,size_t>::iterator it = count.find(inText[i]);
            (it->second)++;
        }
        else 
        {
            count.insert(make_pair(inText[i],(size_t)(1)));
        }
    }
    for (map<string,size_t>::iterator it = count.begin(); it != count.end(); ++it)
    {
        HeapItem* item = new HeapItem();
        item->total = it->second;
        (item->keys).insert(it->first);
        h.push(*item);
        keycode.insert(make_pair(it->first,""));
    }
    int heapcount = count.size();
    while (heapcount >= 2)
    {
        HeapItem top1 = h.top();
        h.pop();
        HeapItem top2 = h.top();
        h.pop();
        HeapItem* newitem = new HeapItem();
        (newitem->total) = top1.total + top2.total;
        set<string>::iterator it1;
        for (it1 = (top1.keys).begin(); it1 != (top1.keys).end(); ++it1)
        {
            if (keycode.find(*it1) != keycode.end())
            {
                keycode[*it1] = "0" + keycode[*it1];
                (newitem->keys).insert(*it1);
            }
        }
        set<string>::iterator it2;
        for (it2 = (top2.keys).begin(); it2 != (top2.keys).end(); ++it2)
        {
            if (keycode.find(*it2) != keycode.end())
            {
                keycode[*it2] = "1" + keycode[*it2];
                (newitem->keys).insert(*it2);
            }
        }
        h.push(*newitem);
        heapcount--;
    }
    for (map<string,string>::iterator it = keycode.begin(); it != keycode.end(); ++it)
    {
        codes.insert(make_pair((it->second),(it->first)));
    }
    for (unsigned int i = 0; i < inText.size(); i++)
    {
        map<string,string>::iterator it = keycode.find(inText[i]);
        if (it != keycode.end())
        {
            outText += (it->second);
        }
    }
}

// To be completed
void HuffmanCoder::decompress(
    const CompressedData& inText, 
    const CodeKeyMap& codes, 
    RawTextVector& outText)
{
    // Clear old contents of the output parameter
    outText.clear();
    // Add your code here
    string inputCode;
    inputCode = "";
    // create the decompressed text by reading one char at a time and, 
    // since Huffman codes are prefix codes, once the string matches 
    // a key in the code map, just substitute the word and start again
    for (int i = 0; i < (int)(inText.size()); i++)
    {
        inputCode += inText[i];
        map<string,string>::const_iterator it = codes.find(inputCode);
        if (it != codes.end())
        {
            outText.push_back(it->second);
            inputCode = "";
        }
    }
}

// Complete
double HuffmanCoder::ratio(const RawTextVector& inText, const CompressedData& outText, const CodeKeyMap& codes)
{
    // 2 bytes per entry
    double rawSize = 2 * inText.size(); 
    // each character in outText is a bit so convert to bytes
    double compressedSize = (outText.size() + 7) / 8; 
    for(const auto& pair : codes) {
        compressedSize += 2 + pair.first.size()+1; // 2 bytes for 16-bit val + string of 1,0 + null char
    }
    cout << "Original size (bytes): " << rawSize << endl;
 
    cout << "Compressed size (bytes): " << compressedSize << endl;
    double compressionRatio = rawSize / compressedSize;
    cout << "Compression ratio: " << setprecision(2) << fixed << compressionRatio << endl;
    return compressionRatio;
}

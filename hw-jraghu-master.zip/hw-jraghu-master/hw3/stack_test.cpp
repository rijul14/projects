#include "stack.h"
#include <iostream>

using namespace std;

int main () {
    Stack<int> s1;
    s1.push(1);
    s1.push(2);
    s1.push(3);
    s1.push(8);
    s1.push(5);
    cout << s1.top() << endl;
    s1.pop();
    cout << s1.top() << endl;
    cout << s1.size() << endl;
    s1.pop();
    s1.pop();
    s1.pop();
    cout << s1.top() << endl;
    cout << s1.size() << endl;
    s1.pop();
    cout << s1.empty() << endl;
}
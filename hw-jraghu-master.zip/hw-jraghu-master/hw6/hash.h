#ifndef HASH_H
#define HASH_H

#include <iostream>
#include <cstdlib>
#include <ctime>

typedef std::size_t HASH_INDEX_T;

struct MyStringHash {
    HASH_INDEX_T rValues[5] { 983132572, 1468777056, 552714139, 984953261, 261934300 };
    MyStringHash(bool debug = true)
    {
        if(false == debug){
            generateRValues();
        }
    }

    // hash function entry point (i.e. this is h(k))
    HASH_INDEX_T operator()(const std::string& k) const
    {
        // Add your code here
        int arr[(int)k.size()]; //array of base-36 integers representing the input string 
        for (long unsigned int i = 0; i < k.size(); i++) {
            arr[i] = (int)letterDigitToNumber(k[i]); 
        }
        unsigned long long w[5]; //array of 64-bit integers representing substrings of input string
        for (int i = 0; i < 5; i++) {
            w[i] = 0; //set to 0 initially
        }
        int index = 4; //index of w to begin with because values of w are set in reverse order
        int mult = 1; //helps find base-36 integers corresponding to substrings
        std::string modifiedk = k; //removes last 6 characters (if possible) after every iteration
        while (1) {
            std::string temp; //holds substring
            int startInd; 
            int a[6]; //array of base-36 integers corresponding to substring
            if (modifiedk.size() > 6) { //checks whether string's length is more than 6
                temp = modifiedk.substr(modifiedk.size()-6,6); //holds last 6 characters
                startInd = (int)k.size() - (6 * mult); //identifies index of k corresponding to start of substring
                for (int i = 0; i < 6; i++) {
                    a[i] = (int)arr[startInd + i]; //allocates base-36 integers
                }
            }
            else {
                temp = modifiedk;
                startInd = 0; //starting index is beginning of string
                for (int i = 0; i < 6; i++) {
                    if ((int)modifiedk.size() - i - 1 < 0) { //ensures that latter indices of 'a' are allocated before initial indices
                        a[5 - i] = 0; //sets to 0 if substring is less than 6
                    }
                    else {
                        a[5 - i] = arr[(int)modifiedk.size() - i - 1];
                    }
                }
            }
            w[index] = (a[0] * 36) + a[1]; 
            for (int i = 2; i < 6; i++) { //base conversion method to improve runtime and avoid repeated calls to 'pow'
                w[index] = (w[index] * 36) + a[i];
            }
            if (modifiedk.size() <= 6) { //condition to exit the loop
                break;
            }
            modifiedk = modifiedk.substr(0,modifiedk.size()-6); //removes last 6 characters of string
            mult++; //incremented as starting index of new substring is now closer to 0
            index--; //works on next 64-bit integer
        }
        HASH_INDEX_T hashindex = 0; //final hash result
        for (int i = 0; i < 5; i++) {
            hashindex += (rValues[i] * w[i]);
        }
        return hashindex;
    }

    // A likely helper function is to convert a-z,0-9 to an integral value 0-35
    HASH_INDEX_T letterDigitToNumber(char letter) const
    {
        // Add code here or delete this helper function if you do not want it
        int num;
        if ((int)letter >= 48 && (int)letter <= 57) { //checks whether character is a number
            num = (int)(letter) - 22; //ensures it is between 26 and 35
        }
        else if ((int)letter >= 65 && (int)letter <= 90) { //checks whether character is an uppercase letter
            num = (int)(letter) - 65; //ensures it is between 0 and 25
        }
        else if ((int)letter >= 97 && (int)letter <= 122) { //checks whether character is a lowercase letter
            num = (int)(letter) - 97; //ensures it is between 0 and 25
        }
        return (size_t)num;
    }

    // Add code to generate the random R values
    void generateRValues()
    {
        // Be sure to seed the random number generator
        srand(time(0));
        for (int i = 0; i < 5; i++) {
            rValues[i] = rand(); //allocates random 'r' values
        }
    }

};

#endif

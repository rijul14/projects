Name: Rijul Raghu 
Email: jraghu@usc.edu

Compilation:
- Compile all programs using 'make'
- Compile 'ht-test.cpp' using 'make ht-test'
- Compile 'ht-perf.cpp' using 'make ht-perf'
- Compile 'str-hash-test.cpp' using 'make str-hash-test'
- Compile 'pairless.cpp' using 'make pairless'

Design Decisions:

'hash.h' implementation:
- Implemented a helper function 'letterDigitToNumber' that converts a character to a base-36 integer, for which letters a-z correspond to 0-25 and numbers 0-9 correspond to 26-35.
- Erased the relevant substring after each iteration for ease of access of the next substring.

'ht.h' implementation:
- Initialized a variable 's' that increments by 1 after every insertion but does not decrement by 1 after deletions in order to compute an accurate loading factor at the time of resizing and otherwise.
- Initialized a vector 'temptable' in the function 'resize()'. The vector copies the 'current' table which is set to resize and re-hash every element, and ensures that no HashItem pointers are lost.

'pairless.cpp' implementation:
- Initialized a hash table to determine the 'pairless' integers due to the O(1) 'insert', 'remove', and 'find' operations it provides.


#include <iostream>
#include <fstream>
#include <cstdio>
#include "ht.h"
using namespace std;


int main(int argc, char* argv[])
{
    // Check the number of parameters is correct.
	if(argc < 3)
	{
		std::cerr << "Usage: ./missing [input] target" << std::endl;
		return 1;
	}

    int target = atoi(argv[2]);
    int pairlessCount = 0;
    
    ifstream ifile(argv[1]);
    if(ifile.fail()){
        std::cerr << "Unable to open input file" << std::endl;
        return 1;
    }
    // Your code here
    HashTable<int,int,QuadraticProber,std::hash<int>,std::equal_to<int> > ht; //hash table for O(1) insert,find, and remove
    int x;
    while (ifile >> x) {
        if (ht.find(x) == nullptr) { //inserts new item if key does not exist
            ht.insert({x,1});
        }
        else { //if key is found, its value is incremented by 1
            ht[x] += 1;
        }
        if (ht.find(target-x) == nullptr) { //if it does not belong in a pair, pairlessCount is incremented by 1
            pairlessCount++;
        }
        else if (ht.find(target-x) != nullptr) {
            if (target - x == x && ht[x] == 1) { //checks whether paired element is element itself and whether its value is 1
                pairlessCount++; //increments by 1 to ensure under-counting does not occur
            }
            else {
                pairlessCount--; 
                ht[x]--; //decrements key's value by 1
                ht[target-x]--; //decrements paired element's value by 1
                if (ht[x] == 0) { //indicates removal of item
                    ht.remove(x);
                }
                if (target - x != x) { //avoids bad access when x and target - x are equal
                    if (ht[target-x] == 0) {
                        ht.remove(target-x); //indicates removal of paired element
                    }
                }
            }
        }
    }

    // Do not change this code. Ensure your final count of 
    // unmatched/pairless numbers is in the variable: pairlessCount
    std::cout << "Unmatched items: " << pairlessCount << std::endl;

    ifile.close();

    return 0;
}
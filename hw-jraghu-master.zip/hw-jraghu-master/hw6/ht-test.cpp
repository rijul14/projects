#include "ht.h"
#include <unordered_map>
#include <iostream>
#include <utility>
#include <string>
#include <sstream>
#include <functional>
using namespace std;
int main()
{
    HashTable<std::string, int, QuadraticProber, std::hash<std::string>, std::equal_to<std::string> > ht;
    for(size_t i = 0; i < 4; i++){
        std::stringstream ss;
        ss << "hi" << i;
        ht.insert({ss.str(), i});
    }
    ht.reportAll(cout);
    ht.remove("hi1");
    ht.remove("hi2");
    ht.insert({"hi4",4});
    ht.insert({"hi5",5});
    ht.reportAll(cout);
    ht.insert({"hi6",6});
    ht.insert({"hi7",7});
    ht.insert({"hi8",8});
    ht.insert({"hi9",9});
    ht.insert({"hi10",10});
    ht.insert({"hi11",11});
    ht.insert({"hi12",12});
    ht.reportAll(cout);
    if( ht.find("hi1") != nullptr ){
        cout << "Found hi1" << endl;
    }
    if( ht.find("doesnotexist") == nullptr ){
        cout << "Did not find: doesnotexist" << endl;
    }
    cout << "HT size: " << ht.size() << endl;
    ht.remove("hi7");
    ht.remove("hi9");
    cout << "HT size: " << ht.size() << endl;
    if( ht.find("hi9") != nullptr ){
        cout << "Found hi9" << endl;
    }
    else {
        cout << "Did not find hi9" << endl;
    }
    ht.insert({"hi7",17});
    cout << "size: " << ht.size() << endl;

    return 0;
}

#include <iostream>
#include <stdexcept>
#include <iomanip>
#include <string>
#include <sstream>
#include <stdexcept>
#include "spmat.h"
using namespace std;

#ifdef SPARSE_DEBUG
#include "spmat-debug.h"    
// global instance of the debug helper
SparseMatrixDebugHelper debug;
#endif


// Define and initialize the constant static member npos here
const size_t SparseMatrix::npos = (size_t)-1;

// ----------------------------------------------------------------------------
// ------------------ Coord struct Implementation -----------------------------
// ----------------------------------------------------------------------------

// Constructor
// COMPLETE 
SparseMatrix::Coord::Coord(size_t row, size_t col) :
    r(row), c(col)
{
}

// operator[] accessors
// To be completed - Must adhere it requirements in the .h
size_t& SparseMatrix::Coord::operator[](size_t index) {
    if (index != ROW && index != COL)
    {
        throw std::out_of_range("index must be 0 or 1");
    }
    if (index == ROW)
    {
        return this->r;
    }
    return this->c;
}

size_t const& SparseMatrix::Coord::operator[](size_t index) const {
    if (index != ROW && index != COL)
    {
        throw std::out_of_range("index must be 0 or 1");
    }
    if (index == ROW)
    {
        return this->r;
    }
    return this->c;
}

// operator== comparison function
// To be completed - Must adhere it requirements in the .h
bool SparseMatrix::Coord::operator==(const Coord& rhs) const
{
    if ((this->r == rhs[ROW]) && (this->c == rhs[COL]))
    {
        return true;
    }
    return false; 
}


// operator != comparison function
// COMPLETE
bool SparseMatrix::Coord::operator!=(const Coord& rhs) const
{
    return !operator==(rhs);
}

// ----------------------------------------------------------------------------
// ------------------ SparseItem struct Implementation ------------------------
// ----------------------------------------------------------------------------

// Constructor
// COMPLETE 
SparseMatrix::SparseItem::SparseItem(Coord coord, double v)
{
    this->val = v;
    this->coord = coord;
    this->prev[ROW] = this->prev[COL] = nullptr;
    this->next[ROW] = this->next[COL] = nullptr;
}

// ----------------------------------------------------------------------------
// ----------------- SparseMatrix class Implementation ------------------------
// ----------------------------------------------------------------------------

// Constructor
// To be completed - Must adhere to requirements in the .h
SparseMatrix::SparseMatrix(size_t n) : 
    /* Add code as needed */ n_(n)
{
    if(0U == n_) {
        throw std::invalid_argument("n must be greater than 0");
    }
    /* Add code as needed */
    for (size_t i = 0; i < 2; i++)
    {
        lists_[i] = new SparseItem* [n_];
    }
}

// Destructor
// To be completed 
SparseMatrix::~SparseMatrix() 
{
    for (size_t i = 0; i < 2; i++)
    {
        for (size_t j = 0; j < n_; j++)
        {
            if (lists_[i][j] != nullptr)
            {
                deleteNode(lists_[i][j]);
            }
        }
    }
}

// COMPLETE
SparseMatrix::SparseItem* SparseMatrix::createSparseItem(const SparseMatrix::Coord& coord, double val)
{
    SparseItem* ptr = new SparseItem(coord, val);
#ifdef SPARSE_DEBUG    
    debug.addItem(ptr);
#endif
    return ptr;
}

// COMPLETE
SparseMatrix::SparseItem* SparseMatrix::lowerBound(size_t list, Coord target_coord ) const
{
    SparseItem* head = this->lists_[list][target_coord[list]];
    size_t target_index = target_coord[1-list];

    if(head == nullptr) {
        return nullptr;
    }
    else if( head->coord[1-list] > target_index ) {
        return nullptr;
    }
    else {
        while(  head->next[list] != nullptr && 
                head->next[list]->coord[1-list] <= target_index  ) 
        {
            head = head->next[list];
        }
        return head;        
    }
}


// COMPLETED
double SparseMatrix::get(const Coord& coord) const
{
    if( coord[ROW] >= n_ || coord[COL] >= n_ ) {
        throw std::invalid_argument("Bad coordinates");
    }
    SparseItem* head = lowerBound(ROW, coord );
    if(nullptr == head || head->coord[COL] != coord[COL]){
        return 0;
    }
    return head->val;
}

// COMPLETED
void SparseMatrix::print(std::ostream &os) const
{
    os << setprecision(7);
    for(size_t r = 0; r < this->n_; r++) {
        SparseItem* ptr = this->lists_[ROW][r];
        size_t col = 0;
        while(ptr != NULL) {
            while(col < ptr->coord[COL]) {
                os << setw(8) << 0;
                col++;
            }
            os << setw(8) << ptr->val;
            col++;
            ptr = ptr->next[ROW];
        }
        while(col < this->n_) {
            os << setw(8) << 0;
            col++;
        }
        os << endl;
    }
}


// To be completed - Must adhere it requirements in the .h
void SparseMatrix::deleteNode(SparseItem* node)
{
    if(nullptr == node){
        throw std::invalid_argument("argument must not be null");
    }
    /* Add necessary code to update all other pointers */
    /* Note: calling delete is provided for you below  */
    if (node->prev[ROW] != nullptr)
    {
        node->prev[ROW]->next[ROW] = node->next[ROW];
    }
    else 
    {
        if (node->next[ROW] != nullptr)
        {
            lists_[ROW][node->coord[ROW]] = node->next[ROW];
        }
    }
    if (node->prev[COL] != nullptr)
    {
        node->prev[COL]->next[COL] = node->next[COL];
    }
    else 
    {
        if (node->next[COL] != nullptr)
        {
            lists_[COL][node->coord[COL]] = node->next[COL];
        }
    }
    if (node->next[ROW] != nullptr)
    {
        node->next[ROW]->prev[ROW] = node->prev[ROW];
    }
    if (node->next[COL] != nullptr)
    {
        node->next[COL]->prev[COL] = node->prev[COL];
    }
    if (node->prev[ROW] == nullptr && node->next[ROW] == nullptr)
    {
        lists_[ROW][node->coord[ROW]] = nullptr;
    }
    if (node->prev[COL] == nullptr && node->next[COL] == nullptr)
    {
        lists_[COL][node->coord[COL]] = nullptr;
    }
    /* This code should not be altered and should end this function */
#ifdef SPARSE_DEBUG    
    debug.deleteItem(node);
#endif
    delete node;
}

// To be completed - Must adhere it requirements in the .h
void SparseMatrix::set(const Coord& coord, double val)
{
    if (coord[ROW] >= n_|| coord[COL] >= n_)
    {
        throw std::out_of_range("coordinates must be between 0 and n - 1");
    }
    SparseItem* temprow = lowerBound(ROW, coord);
    SparseItem* tempcol = lowerBound(COL, coord);
    if (temprow != nullptr)
    {
        if (temprow->coord == coord && val != 0)
        {
            temprow->val = val;
        }
        else if (temprow->coord == coord && val == 0)
        {
            deleteNode(temprow);
        }
        else if (temprow->coord != coord && val != 0)
        {
            SparseItem* temp = createSparseItem(coord,val);
            if (temprow->next[ROW] != nullptr)
            {
                temprow->next[ROW]->prev[ROW] = temp;
            }
            temp->next[ROW] = temprow->next[ROW];
            temprow->next[ROW] = temp;
            temp->prev[ROW] = temprow;
            if (tempcol != nullptr && tempcol->coord != coord)
            {
                if (tempcol->next[COL] != nullptr)
                {
                    tempcol->next[COL]->prev[COL] = temp;
                }
                temp->next[COL] = tempcol->next[COL];
                tempcol->next[COL] = temp;
                temp->prev[COL] = tempcol;
            }
            else if (tempcol == nullptr)
            {
                if (lists_[COL][coord[COL]] == nullptr)
                {
                    lists_[COL][coord[COL]] = temp;
                }
                else 
                {
                    temp->next[COL] = lists_[COL][coord[COL]];
                    lists_[COL][coord[COL]]->prev[COL] = temp;
                    lists_[COL][coord[COL]] = temp;
                }
            }
        }
    }
    else if (temprow == nullptr && val != 0)
    {
        SparseItem* temp = createSparseItem(coord,val);
        if (lists_[ROW][coord[ROW]] == nullptr)
        {
            lists_[ROW][coord[ROW]] = temp;
        }
        else 
        {
            temp->next[ROW] = lists_[ROW][coord[ROW]];
            lists_[ROW][coord[ROW]]->prev[ROW] = temp;
            lists_[ROW][coord[ROW]] = temp;
        }
        if (tempcol == nullptr)
        {
            lists_[COL][coord[COL]] = temp;
        }
        else if (tempcol != nullptr && tempcol->coord != coord)
        {
            if(tempcol->next[COL] != nullptr)
            {
                tempcol->next[COL]->prev[COL] = temp;
            }
            temp->next[COL] = tempcol->next[COL];
            tempcol->next[COL] = temp;
            temp->prev[COL] = tempcol;
        }
    }

/* Leave these as the last lines of this function */
#ifdef SPARSE_DEBUG    
    try {
        debug.checkConsistency(this);
    }
    catch (std::logic_error& e) {
        cerr << e.what();
    }
#endif
}

// To be completed - Must adhere it requirements in the .h
//   Be sure to meet the run-time requirements
double SparseMatrix::sumDim(const Coord& coord) const
{
    if (coord[ROW] != npos && coord[COL] != npos)
    {
        throw std::invalid_argument("one coordinate value must be npos");
    }
    else if ((coord[ROW] != npos && coord[ROW] >= n_ ) || (coord[COL] != npos && coord[COL] >= n_))
    {
        throw std::out_of_range("coordinates must be between 0 and n - 1");
    }
    double sum = 0;
    if (coord[ROW] == npos)
    {
        SparseItem* head = lists_[COL][coord[COL]];
        while (head != nullptr)
        {
            sum += head->val;
            head = head->next[COL];
        }
    }
    else if (coord[COL] == npos)
    {
        SparseItem* head = lists_[ROW][coord[ROW]];
        while (head != nullptr)
        {
            sum += head->val;
            head = head->next[ROW];
        }
    }
    return sum;
}

// To be completed - Must adhere it requirements in the .h
//   Be sure to meet the run-time requirements
void SparseMatrix::copyDim(const Coord& srcCoord, const Coord& dstCoord)
{
    // Ignore self-copy - leave these as the first lines of the function 
    if( dstCoord == srcCoord) {
        return;
    }

    // Add code to check for exception cases and, if valid, perform the copy
    // of the indicated dimension
    if ((srcCoord[ROW] != npos && srcCoord[COL] != npos) || (dstCoord[ROW] != npos && dstCoord[COL] != npos))
    {
        throw std::invalid_argument("one coordinate value must be npos");
    }
    if ((srcCoord[ROW] != npos && srcCoord[ROW] >= n_) || (srcCoord[COL] != npos && srcCoord[COL] >= n_) || (dstCoord[ROW] != npos && dstCoord[ROW] >= n_) || (dstCoord[COL] != npos && dstCoord[COL] >= n_))
    {
        throw std::out_of_range("coordinates must be between 0 and n - 1");
    }
    size_t src;
    size_t dst;
    Coord dc;
    Coord sc;
    if (dstCoord[ROW] == npos)
    {
        dst = ROW;
        dc[ROW] = 0;
        dc[COL] = dstCoord[COL];
    }
    else 
    {
        dst = COL;
        dc[ROW] = dstCoord[ROW];
        dc[COL] = 0;
    }
    if (srcCoord[ROW] == npos)
    {
        src = ROW;
        sc[ROW] = 0;
        sc[COL] = srcCoord[COL];
    }
    else
    {
        src = COL;
        sc[ROW] = srcCoord[ROW];
        sc[COL] = 0;
    }
    for (size_t i = 0; i < n_; i++)
    {
        if (lowerBound(1-src,sc) == nullptr)
        {
            if (get(sc) != 0)
            {
                SparseItem* temp = createSparseItem(dc,get(sc));
                if (i == 0)
                {
                    lists_[1-dst][dc[1-dst]] = temp;
                }
            }
            else 
            {
                set(dc,0);
            }
        }
        else if (lowerBound(1-src,sc)->coord != sc)
        {
            if (get(sc) != 0)
            {
                SparseItem* temp = createSparseItem(dc,get(sc));
                if (i == 0)
                {
                    lists_[1-dst][dc[1-dst]] = temp;
                }
            }
            else 
            {
                set(dc,0);
            }
        }
        else if (lowerBound(1-src,sc)->coord == sc)
        {
            set(dc,get(sc));
        }
        sc[src]++;
        dc[dst]++;
    }


/* Leave these as the last lines of this function */
#ifdef SPARSE_DEBUG    
    try {
        debug.checkConsistency(this);
    }
    catch (std::logic_error& e) {
        cerr << e.what();
    }
#endif
}


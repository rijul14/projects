## HW1
 
 - Name: Rijul Raghu
 - Email: jraghu@usc.edu

- Compile using 'make debug' or 'make'
- There are errors with Valgrind. Memory deallocation was incorrect, resulting in memory loss. There were also errors because a 'conditional jump or move depends on uninitialised value(s)'.
### Programming Problem Notes

  For each programming problem, let us know:

  - How we should compile your code (`g++` command or `make` target)
  - Design decisions you made or other non-trivial choices for your implementation
  - Any additional tests you wrote and what files those exist in
  - Known errors
  - Anything that might helps us grade (though we will run automated tests), it often does help to know what features may be broken/missing in case we can provide some small partial credit.

 
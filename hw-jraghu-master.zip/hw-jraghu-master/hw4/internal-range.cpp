#include "internal-range.h"
using namespace std;


// You may add any prototypes of helper functions here
int depthCalc(Node* root);

// Now implement the sumInternalRange function and any necessary helpers
int sumInternalRange(Node * root, int depth, int min, int max) {
    if (root == nullptr)
	{
		return 0;
	}
    int count = 0;
    int d = depthCalc(root);
	if (root->key >= min && root->key <= max && d < depth)
	{
		count = 1;
	}
	return (count + sumInternalRange(root->left,depth,min,max) + sumInternalRange(root->right,depth,min,max));
}

int depthCalc(Node* root) {
    if (root->parent == nullptr)
	{
		return 0;
	}
	else 
	{
		return (1 + depthCalc(root->parent));
	}
}
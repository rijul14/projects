Name: Rijul Raghu
Email: jraghu@usc.edu

Compilation:
- Compile all programs using 'make'
- Compile 'internal-range.cpp' using 'make internal-range-test'
- Compile 'bst-test.cpp' using 'make bst-test'

Design Decisions:
BST Implementation:
- Implemented 4 helper functions in 'bst.h': 'deleteTree', 'checkBalance', 'treeHeight', and 'successor'
- 'deleteTree' is recursive in nature and helps clear out the contents of the BST
- 'checkBalance' and 'treeHeight' are recursive in nature and help determine whether the BST is balanced
AVL Tree Implementation:
- Implemented 6 helper functions in 'avlbst.h': 'isLeft', 'isRight', 'rotateLeft', 'rotateRight', 'removeFix', and 'insertFix'
- 'isLeft' and 'isRight' are implemented for convenience and easy abstraction
- 'rotateRight' and 'rotateLeft' perform the modifications required to ensure that the tree is balanced
- 'removeFix' and 'insertFix' are recursive in nature determine whether rotations are required following removals and insertions respectively.
Name: Rijul Raghu
Email: jraghu@usc.edu

Compilation:
- Compile all programs using 'make'
- Compile 'sat_solver.cpp' using 'make sat_solver'
- Compile 'gridpaths.cpp' using 'make gridpaths'

Design Decisions:

'gridpaths.cpp' implementation:
- Implemented a recursive helper function 'gridpathsHelper' that took additional arguments: current 'x' coordinate, current 'y' coordinate, current vector of 'XYPairs', and final list of pathways to return.

'sat_solver.cpp' implementation:
- Implemented a function 'evalFormula' to evaluate the status of the entire formula by making use of the pre-existing 'evalClause' function. The recursive 'satSolve' function uses 'evalFormula' to determine whether the formula can be satisfied by a certain variable assignment.
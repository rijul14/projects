#include <iostream>
#include <vector>
#include <set>
#include <cstdlib>
// for pair
#include <functional>
#include <string>

using namespace std;

// typedef for X,Y pair
typedef std::pair<size_t, size_t> XYPair;

// Utility Prototypes
bool operator==(const XYPair& p1, const XYPair& p2);
void printPaths(const std::vector<std::vector<XYPair> >& results);

// Utility function to compare XY points
bool operator==(const XYPair& p1, const XYPair& p2)
{
  return p1.first == p2.first && p1.second == p2.second;
}


// Primary street grid function prototype
std::vector<std::vector<XYPair> > gridpaths(const XYPair& inter, const XYPair& final);

// Prototype any helper functions here
std::vector<std::vector<XYPair> >& gridpathsHelper(
  size_t x, size_t y, std::vector<XYPair>& currvec, 
  std::vector<std::vector<XYPair> >& paths, const XYPair& inter, const XYPair& final);


// Implement your gridpaths and any helper functions below
std::vector<std::vector<XYPair> > gridpaths(
    const XYPair& inter, 
    const XYPair& final)
{
  std::vector<std::vector<XYPair> > paths;
  if (final.first == 0 && final.second == 0) { //checks whether final point is (0,0)
    return paths;
  }
  if (inter.first > final.first || inter.second > final.second) { //checks whether final point is below or to the left of intermediate point
    return paths;
  }
  std::vector<XYPair> vec; //'current' vector that is recursed
  XYPair p;
  p.first = 0;
  p.second = 0;
  vec.push_back(p); //inserts (0,0) initially
  size_t x1 = 0; //x coordinate that is recursed
  size_t y1 = 0; //y coordinate that is recursed
  paths = gridpathsHelper(x1,y1,vec,paths,inter,final);
  return paths;
}

std::vector<std::vector<XYPair> >& gridpathsHelper(
  size_t x, size_t y, std::vector<XYPair>& currvec, 
  std::vector<std::vector<XYPair> >& paths, const XYPair& inter, const XYPair& final) {
    if (x == final.first && y == final.second) { //checks whether (x,y) is the final coordinate
      paths.push_back(currvec); //current vector with a unique pathway is pushed 
    }
    else {
      if (x + 1 <= inter.first || y + 1 <= inter.second) { //ensures that the intermediate point is reached
        if (x + 1 <= inter.first) { //traverses along x-axis first
          XYPair t;
          t.first = x + 1;
          t.second = y;
          currvec.push_back(t);
          gridpathsHelper(x+1,y,currvec,paths,inter,final);
          currvec.pop_back(); //removes last location until there is an option to move vertically
        }
        if (y + 1 <= inter.second) { //traverses along y-axis after x-axis
          XYPair t;
          t.first = x;
          t.second = y + 1;
          currvec.push_back(t);
          gridpathsHelper(x,y+1,currvec,paths,inter,final);
          currvec.pop_back(); //ensures that all pathways are found and no duplicates occur
        }
      }
      else if (x + 1 <= final.first || y + 1 <= final.second) { //condition is satisfied only after 'inter' point is found
        if (x + 1 <= final.first) { //traverses along x-axis first
          XYPair t;
          t.first = x + 1;
          t.second = y;
          currvec.push_back(t);
          gridpathsHelper(x+1,y,currvec,paths,inter,final);
          currvec.pop_back(); //removes last location until there is an option to move vertically to final location
        }
        if (y + 1 <= final.second){ //traverses along y-axis after all options on x-axis are exhausted
          XYPair t;
          t.first = x;
          t.second = y + 1;
          currvec.push_back(t);
          gridpathsHelper(x,y+1,currvec,paths,inter,final);
          currvec.pop_back(); //ensures that all pathways are found and no duplicates occur
        }
      }
    }
    return paths;
}


// Complete - but can be changed for debugging purposes
int main(int argc, char* argv[])
{
  // Default to intermediate point of 2,3 and final location of 3,4
  size_t ix = 2, iy = 3, fx = 3, fy = 4;
  if(argc >= 5) {
    ix = atoi(argv[1]);
    iy = atoi(argv[2]);
    fx = atoi(argv[3]);
    fy = atoi(argv[4]);
  }
  vector<vector<XYPair> > results;
  results = gridpaths({ix,iy},{fx,fy});  
  printPaths(results);

  return 0;
}

// Prints the results in a clean fashion for human consumption / debugging
void printPaths(const vector<vector<XYPair> >& results)
{
  for( const auto& path : results) {
    for( size_t i = 0; i < path.size()-1; i++ ) 
    {      
      cout << path[i].first << "," << path[i].second << " -> ";
    }
    cout << path.back().first << "," << path.back().second << endl;
  }
  cout << results.size() << " solutions." << endl;

}

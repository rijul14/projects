#include <iostream>
#include <fstream>
#include <sstream>
#include <stdexcept>
#include "twiteng.h"
// Add other header files
#include <map> 
#include <string>
#include <set>
#include <vector>
#include "user.h"
#include "datetime.h"
#include "tweet.h"
#include <algorithm>
#include "util.h"
using namespace std;


// Update as needed
TwitEng::TwitEng()
{
  users.clear();
  tweets.clear();
}

// Update as needed
TwitEng::~TwitEng()
{
  users.clear();
  tweets.clear();
}

// Complete this function
bool TwitEng::parse(char* filename)
{
  ifstream ifile(filename);
  if (ifile.fail()) {
    cerr << "Unable to open " << filename << endl;
    return true;
  }
  int numUsers;
  ifile >> numUsers;
  if (ifile.fail()) {
    cerr << "Unable to read number of users " << endl;
    ifile.close();
    return true;
  }
  // Finish the parsing of the input file. Return false if successful,
  // true otherwise.
  string sline;
  stringstream ss;
  string name;
  string followname;
  getline(ifile,sline);
  for (int count = 0; count < numUsers; count++)
  {
    getline(ifile,sline);
    sline = trim(sline);
    if (ifile.fail())
    {
      ifile.close();
      return true;
    }
    ss << sline;
    ss >> name;
    map<string,User*>::iterator it;
    if (validUser(name) == false)
    {
      User* u = new User(name);
      users.insert(make_pair(name,u));
      it = users.find(name);
    }
    else 
    {
      it = users.find(name);
    }
    while (ss >> followname)
    {
      if (validUser(followname) == false)
      {
        User* m = new User(followname);
        users.insert(make_pair(followname,m));
        (it->second)->addFollowing(m);
        m->addFollower(it->second);
      }
      else 
      {
        map<string,User*>::iterator followit = users.find(followname);
        (it->second)->addFollowing(followit->second);
        (followit->second)->addFollower(it->second);
      }
    }
    ss.clear();
  }
  string tweetline;
  while (getline(ifile,tweetline))
  {
    tweetline = trim(tweetline);
    ss << tweetline;
    DateTime d;
    string username;
    string tweettext = "";
    string eachword;
    ss >> d >> username;
    map<string,User*>::iterator it = users.find(username);
    while (ss >> eachword)
    {
      tweettext += eachword + " ";
    }
    tweettext = trim(tweettext);
    Tweet* fintweet = new Tweet(it->second,d,tweettext);
    if (it != users.end())
    {
      (it->second)->addTweet(fintweet);
    }
    tweets.insert(fintweet);
    ss.clear();
  }
  ifile.close();
  return false;
}

// Implement other member functions below
void TwitEng::addTweet(const string& username, const DateTime& time, const string& text) {
  if (validUser(username))
  {
    map<string,User*>::iterator it = users.find(username);
    Tweet* t = new Tweet (it->second,time,text);
    (it->second)->addTweet(t);
    tweets.insert(t);
  }
}

vector<Tweet*> TwitEng::search(vector<string>& terms, int strategy) {
  vector<Tweet*> fintweets;
  set <Tweet*> result;
  map<string,set<Tweet*> > record = hash();
  if (strategy == 0)
  {
    result = intersection(terms,record);
  }
  else if (strategy == 1)
  {
    result = comb(terms,record);
  }
  for (set<Tweet*>::iterator it = result.begin(); it != result.end(); ++it)
  {
    fintweets.push_back(*it);
  }
  return fintweets;
}

void TwitEng::dumpFeeds() {
  for (map<string,User*>::iterator it = users.begin(); it != users.end(); ++it)
  {
    string filename;
    if (it->first != "")
    {
      filename = (it->first) + ".feed";
    }
    ofstream ofile (filename);
    ofile << (it->first) << endl;
    vector<Tweet*> final;
    vector<Tweet*> feed = (it->second)->getFeed();
    if (feed.size() != 0)
    {
      for (vector<Tweet*>::iterator vecit = feed.begin(); vecit!= feed.end(); ++vecit)
      {
        if ((*vecit)->checkEmpty(**vecit) == false)
        {
          final.push_back(*vecit);
        }
      }
    }
    set<User*> following = (it->second)->following();
    if (following.size() != 0)
    {
      for (set<User*>::iterator setit = following.begin(); setit != following.end(); ++setit)
      {
        vector<Tweet*> vecfollow = (*setit)->getFeed();
        for (vector<Tweet*>::iterator fol = vecfollow.begin(); fol != vecfollow.end(); ++fol)
        {
          if ((*fol)->checkEmpty(**fol) == false)
          {
            final.push_back(*fol);
          }
        }
      }
    }
    sort(final.begin(), final.end(), TweetComp());
    for (vector<Tweet*>::iterator it = final.begin(); it != final.end(); ++it)
    {
      ofile << (**it) << endl;
    }
    ofile.close();
  }
}

bool TwitEng::validUser(const string& name) const {
  if (users.find(name) == users.end())
  {
    return false;
  }
  return true;
}

map<string,set<Tweet*> > TwitEng::hash() {
  map<string,set<Tweet*> > hashrecord;
  for (set<Tweet*>::iterator it = tweets.begin(); it != tweets.end(); ++it)
  {
    set<string> hashtags = (*it)->hashTags();
    for (set<string>::iterator setit = hashtags.begin(); setit != hashtags.end(); ++setit)
    {
      string temp = *setit;
      convLower(temp);
      if (hashrecord.find(temp) != hashrecord.end())
      {
        map<string,set<Tweet*> >::iterator mapit = hashrecord.find(temp);
        (mapit->second).insert(*it);
      }
      else {
        set<Tweet*> add;
        add.insert(*it);
        hashrecord.insert(make_pair(temp,add));
      }
    }
  }
  return hashrecord;
}

set<Tweet*> intersection (vector<string>& terms, map<string,set<Tweet*> >& hash) {
  set<Tweet*> final;
  if (terms.size() > 2)
  {
    set<Tweet*> set1;
    set<Tweet*> set2;
    for (vector<string>::iterator it = terms.begin(); it != terms.end() - 1; ++it)
    {
      for(set<Tweet*>::iterator setit = hash.find(*it)->second.begin(); setit != hash.find(*it)->second.end();
      ++setit)
      {
        set1.insert(*setit);
      } 
    }
    set2 = hash.find(terms[terms.size() - 1])->second;
    for (set<Tweet*>::iterator it = set1.begin(); it != set1.end(); ++it)
    {
      if (set2.find(*it) != set2.end())
      {
        final.insert(*it);
      }
    }
  }
  else if (terms.size() == 2)
  {
    set<Tweet*> set1 = hash.find(terms[0])->second;
    set<Tweet*> set2 = hash.find(terms[1])->second;
    for (set<Tweet*>::iterator it = set1.begin(); it != set1.end(); ++it)
    {
      if (set2.find(*it) != set2.end())
      {
        final.insert(*it);
      }
    }
  }
  else 
  {
    set<Tweet*> temp = hash.find(terms[0])->second;
    final = temp;
  }
  return final;
}

set<Tweet*> comb (vector<string>& terms, map<string,set<Tweet*> >& hash) {
  set<Tweet*> final;
  for (vector<string>::iterator it = terms.begin(); it != terms.end(); ++it)
  {
    for(set<Tweet*>::iterator setit = hash.find(*it)->second.begin(); setit != hash.find(*it)->second.end();
    ++setit)
    {
      final.insert(*setit);
    }
  }
  return final;
}


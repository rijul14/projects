#include "tweet.h"
#include "user.h"
#include <iostream>
#include <string>
#include <set>
#include <list>
#include <vector>
#include <algorithm>

using namespace std;

User::User(std::string name) {
    name_ = name;
}

User::~User() {
    follower.clear();
    follow.clear();
    mytweets.clear();
}

string User::name() const {
    return name_;
}

set<User*> User::followers() const {
    return follower;
}

set<User*> User::following() const {
    return follow;
}
list<Tweet*> User::tweets() const {
    return mytweets;
}

void User::addFollower(User* u) {
    follower.insert(u);
}

void User::addFollowing(User* u) {
    follow.insert(u);
}

void User::addTweet(Tweet* t) {
    mytweets.push_back(t);
}

vector<Tweet*> User::getFeed() {
    vector<Tweet*> myfeed;
    for (list<Tweet*>::iterator it = mytweets.begin(); it != mytweets.end(); ++it)
    {
        if ((*it)->checkEmpty(**it) == false)
        {
            myfeed.push_back(*it);
        }
    }
    sort(myfeed.begin(), myfeed.end(), TweetComp());
    return myfeed;
}

bool User::operator<(const User& other) const {
    if (this->name_ < other.name_)
    {
        return true;
    }
    return false;
}
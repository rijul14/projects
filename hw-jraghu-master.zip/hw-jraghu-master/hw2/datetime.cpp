#include "datetime.h"
#include <iostream>
#include <sstream>
#include <string>
#include <ctime>

using namespace std;

DateTime::DateTime() {

}

DateTime::DateTime(int hh, int mm, int ss, int year, int month, int day) {
    hour = hh;
    min = mm;
    sec = ss;
    this->year = year;
    this->month = month;
    this->day = day;
}

bool DateTime::operator<(const DateTime& other) const {
    if (this->year < other.year)
    {
        return true;
    }
    else if (this->year > other.year)
    {
        return false;
    }
    if (this->month < other.month)
    {
        return true;
    }
    else if (this->month > other.month)
    {
        return false;
    }
    if (this->day < other.day)
    {
        return true;
    }
    else if (this->day > other.day)
    {
        return false;
    }
    if (this->hour < other.hour)
    {
        return true;
    }
    else if (this->hour > other.hour)
    {
        return false;
    }
    if (this->min < other.min)
    {
        return true;
    }
    else if (this->min > other.min)
    {
        return false;
    }
    if (this->sec < other.sec)
    {
        return true;
    }
    else if (this->sec > other.sec)
    {
        return false;
    }
    return false;
}

ostream& operator<<(std::ostream& os, const DateTime& other) {
    os << other.year << "-";
    if (other.month/10 == 0)
    {
        os << "0" << other.month << "-";
    }
    else 
    {
        os << other.month << "-";
    }
    if (other.day/10 == 0)
    {
        os << "0" << other.day << " ";
    }
    else 
    {
        os << other.day << " ";
    }
    if (other.hour/10 == 0)
    {
        os << "0" << other.hour << ":";
    }
    else 
    {
        os << other.hour << ":";
    }
    if (other.min/10 == 0)
    {
        os << "0" << other.min << ":";
    }
    else 
    {
        os << other.min << ":";
    }
    if (other.sec/10 == 0)
    {
        os << "0" << other.sec;
    }
    else 
    {
        os << other.sec;
    }                
    return os;
}

istream& operator>>(std::istream& is, DateTime& dt) {
    string date;
    string ttime;
    is >> date >> ttime;
    char punct;
    stringstream ss;
    ss << date;
    ss >> dt.year >> punct >> dt.month >> punct >> dt.day;
    ss.clear();
    ss << ttime;
    ss >> dt.hour >> punct >> dt.min >> punct >> dt.sec;
    return is;
}
#include <iostream>
#include <string>
#include <vector>
#include <set>
#include "datetime.h"
#include "tweet.h"
#include "user.h"
#include <sstream>
#include <map>

using namespace std;

Tweet::Tweet() {
}

Tweet::Tweet(User* user, const DateTime& time, const std::string& text) {
    u = user;
    time_ = time;
    text_ = text;
}

DateTime const & Tweet::time() const {
    return time_;
}

string const & Tweet::text() const {
    return text_;
}

set<string> Tweet::hashTags() const {
    set<string> hashtag;
    stringstream ss;
    ss << text_;
    string word;
    while (ss >> word)
    {
        if (word[0] == '#')
        {
            string temp = word.substr(1,word.size()-1);
            hashtag.insert(temp);
        }
    }
    return hashtag;
}

bool Tweet::operator<(const Tweet& other) const {
    if (this->time_ < other.time_)
    {
        return true;
    }
    return false;
}

ostream& operator<<(std::ostream& os, const Tweet& t) {
    os << t.time_ << " " << (t.u)->name() << " " << t.text_;
    return os;
}

User* Tweet::user() const {
    return u;
}

bool Tweet::checkEmpty(Tweet& t) const {
    string txt = t.text();
    if (txt[0] == ' ')
    {
        return true;
    }
    return false;
}

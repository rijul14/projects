#include "cmdhandler.h"
#include "util.h"
#include <ctime>
using namespace std;

QuitHandler::QuitHandler()
{

}

QuitHandler::QuitHandler(Handler* next)
  : Handler(next)
{

}

bool QuitHandler::canHandle(const std::string& cmd) const
{
	return cmd == "QUIT";

}

Handler::HANDLER_STATUS_T QuitHandler::process(TwitEng* eng, std::istream& instr) const
{
	eng->dumpFeeds();
	return HANDLER_QUIT;
}

AndHandler::AndHandler()
{

}

AndHandler::AndHandler(Handler* next)
  : Handler(next)
{

}

bool AndHandler::canHandle(const std::string& cmd) const
{
	return cmd == "AND";

}

Handler::HANDLER_STATUS_T AndHandler::process(TwitEng* eng, std::istream& instr) const
{
	string word;
	vector<string> words;
	while (instr >> word)
	{
		convLower(word);
		words.push_back(word);
	}
	vector<Tweet*> tweetsearch = eng->search(words,0);
	displayHits(tweetsearch);
	return HANDLER_OK;
}

OrHandler::OrHandler()
{

}

OrHandler::OrHandler(Handler* next)
  : Handler(next)
{

}

bool OrHandler::canHandle(const std::string& cmd) const
{
	return cmd == "OR";

}

Handler::HANDLER_STATUS_T OrHandler::process(TwitEng* eng, std::istream& instr) const
{
	string word;
	vector<string> words;
	while (instr >> word)
	{
		convLower(word);
		words.push_back(word);
	}
	vector<Tweet*> tweetsearch = eng->search(words,1);
	displayHits(tweetsearch);
	return HANDLER_OK;
}

TweetHandler::TweetHandler()
{

}

TweetHandler::TweetHandler(Handler* next)
  : Handler(next)
{

}

bool TweetHandler::canHandle(const std::string& cmd) const
{
	return cmd == "TWEET";

}

Handler::HANDLER_STATUS_T TweetHandler::process(TwitEng* eng, std::istream& instr) const
{
	string name,textword;
	DateTime* t = new DateTime();
	string text = "";
	time_t rawtime;
	struct tm * timeinfo;       
	time (&rawtime);
	timeinfo = localtime(&rawtime);
	t->year = 1900 + timeinfo->tm_year;
	t->month = 1 + timeinfo->tm_mon;
	t->day = timeinfo->tm_mday;
	t->hour = timeinfo->tm_hour;
	t->min = timeinfo->tm_min;
	t->sec = timeinfo->tm_sec;
	instr >> name;
	while (instr >> textword)
	{
		text += textword + " ";
	}
	text = trim(text);
	eng->addTweet(name,*t,text);
	return HANDLER_OK;
}


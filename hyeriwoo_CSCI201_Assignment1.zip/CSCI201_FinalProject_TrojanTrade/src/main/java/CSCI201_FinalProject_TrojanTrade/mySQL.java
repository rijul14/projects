package CSCI201_FinalProject_TrojanTrade;

public class mySQL {
	public final static String db = "jdbc:mysql://localhost:3306/trojantrade";
	public final static String user = "root";
	public final static String pwd = "j97382q100";
}
